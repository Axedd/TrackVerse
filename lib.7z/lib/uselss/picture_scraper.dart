import 'package:http/http.dart' as http;
import 'package:html/parser.dart' show parse;

Future<List<String>> scrapeInternet(String url) async {
  var parsedURL = Uri.parse(url);
  var response = await http.get(parsedURL, headers: {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  });
  if (response.statusCode == 200) {
    var document = parse(response.body);
    var pictures = document.querySelectorAll('img');
    List<String> images = [];
    for (var i = 0; i < pictures.length && i < 5; i++) {
      var src = pictures[i].attributes['src'];
      if (src != null && src.isNotEmpty) {
        images.add(src);
      }
    }
    return images;
  } else {
    print('Failed to load data, status code: ${response.statusCode}');
    return [];
  }
}

Future<void> scrapeTest(String url) async {
  var parsedURL = Uri.parse(url);
  var response = await http.get(parsedURL, headers: {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Cookie':
        'CookieInformationConsent=%7B%22website_uuid%22%3A%22b408e9ce-33ad-4b8c-b8bd-7e2baea8ec0a%22%2C%22timestamp%22%3A%222024-07-23T18%3A22%3A36.788Z%22%2C%22consent_url%22%3A%22https%3A%2F%2Fwww.bilka.dk%2F%3Fgad_source%3D1%26gclid%3DCjwKCAjwqf20BhBwEiwAt7dtdWEJB-kpBv25LUOUtnFBoBn6QqyBxPT80EdVDxVnYk4sPpx57soISRoCcNYQAvD_BwE%26gclsrc%3Daw.ds%22%2C%22consent_website%22%3A%22Bilka%22%2C%22consent_domain%22%3A%22www.bilka.dk%22%2C%22user_uid%22%3A%2202e2b4ff-c9f7-4af4-b9a6-ae2df130a446%22%2C%22consents_approved%22%3A%5B%22cookie_cat_necessary%22%5D%2C%22consents_denied%22%3A%5B%22cookie_cat_functional%22%2C%22cookie_cat_statistic%22%2C%22cookie_cat_marketing%22%2C%22cookie_cat_unclassified%22%5D%2C%22user_agent%22%3A%22Mozilla%2F5.0%20%28Macintosh%3B%20Intel%20Mac%20OS%20X%2010_15_7%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F126.0.0.0%20Safari%2F537.36%22%7D'
  });

  // Add a delay to wait for any potential asynchronous content loading
  await Future.delayed(Duration(seconds: 5));

  var document = parse(response.body);

  var pictures = document.querySelectorAll('span.product-price__integer');
  print(pictures);

  if (pictures.isEmpty) {
    print('No elements found with the selector span.product-price__integer');
  } else {
    for (var picture in pictures) {
      print(picture.text);
    }
  }
}

import 'package:flutter/foundation.dart';

class ServiceDB extends ChangeNotifier {
  List<Map<dynamic, dynamic>> _dataList = [];

  List<Map<dynamic, dynamic>> get dataList => _dataList;



  static double distanceBetween() {
    return 5;
  }

  Future<void> fetchBeverages() async {
    // Simulate fetching data from an API or database
    await Future.delayed(Duration(seconds: 2));
    _dataList = [
      {'type': 'Coffee', 'quantity': 10},
      {'type': 'Tea', 'quantity': 5},
      {'type': 'Juice', 'quantity': 8},
    ];
    notifyListeners();
  }

  void addBeverage(Map<dynamic, dynamic> beverage) {
    _dataList.add(beverage);
    notifyListeners();
  }

  void removeBeverage(int index) {
    _dataList.removeAt(index);
    notifyListeners();
  }
}
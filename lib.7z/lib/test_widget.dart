


import 'package:flutter/material.dart';
import 'package:app/service.dart';
import 'package:provider/provider.dart';

class DataViewerState extends StatefulWidget {
  const DataViewerState({super.key});

  @override
  State<DataViewerState> createState() => __DataViewerStateState();
}

class __DataViewerStateState extends State<DataViewerState> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(onPressed: () => {
      print(Provider.of<ServiceDB>(context, listen: false).dataList)
    }, child: Text("1. WIDGET"));
  }
}
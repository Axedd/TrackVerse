import 'dart:developer';

import 'package:app/dropdown_widget.dart';
import 'package:app/service_db.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://wbkncqghgyqvpxcbveus.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6India25jcWdoZ3lxdnB4Y2J2ZXVzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjE3NTk2NjIsImV4cCI6MjAzNzMzNTY2Mn0.HKgVYBkvm7Gdm7wQP6WYFevynMcAijL1Hnl4jDwaTQ4',
  );

  final serviceDB = ServiceDB();
  await serviceDB.getData();

  runApp(
    ChangeNotifierProvider(
      create: (_) => serviceDB,
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late TextEditingController _controller;
  late TextEditingController _controllerQuantity;
  String selectedBeverage = "None";
  double? selectedQuantity = 0.00;
  GlobalKey<BeverageDropdownState> dropdownKey = GlobalKey<BeverageDropdownState>();
  int choice = 0;


  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    _controllerQuantity = TextEditingController();
    selectedBeverage = Provider.of<ServiceDB>(context, listen: false).beverageChosen!;
    selectedQuantity = Provider.of<ServiceDB>(context, listen: false).beverageAmount!; 
  }

  @override
  void dispose() {
    _controller.dispose();
    _controllerQuantity.dispose();
    super.dispose();
  }



  void updateBeverage(String type, double quantity) {
    // Ensure that you are using the ServiceDB instance from the provider
    Provider.of<ServiceDB>(context, listen: false).updateDataValues(type, quantity);
    setState(() {
      selectedBeverage = type;
      selectedQuantity = quantity;
    });
  }

  void changeChoice(int option) {
    setState(() {
      choice = option;
    });
  }

  void submit() {
    if (choice == 0) {
      try {
        double newQuantity = double.parse(_controllerQuantity.text);
        updateBeverage(selectedBeverage, selectedQuantity! + newQuantity);
      } catch (error) {
        print('ERROR: $error');
      }
    } else if (choice == 1) {
      Provider.of<ServiceDB>(context, listen: false).addBeverage(_controller.text, double.parse(_controllerQuantity.text));
    }
  }


  @override
  Widget build(BuildContext context) {
  
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Beverage Manager'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                choice == 0
                    ? BeverageDropdown(
                        key: dropdownKey,
                        onSelected: updateBeverage,
                        dropdownValue: "Pepsi",
                      )
                    : TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          labelText: 'Enter Beverage Type',
                          border: OutlineInputBorder(),
                        ),
                      ),
                SizedBox(height: 10),
                TextField(
                  controller: _controllerQuantity,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Quantity',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () {
                        changeChoice(0);
                      },
                      child: Text(
                        'Add Amount',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(width: 20),
                    InkWell(
                      onTap: () {
                        changeChoice(1);
                      },
                      child: Text(
                        'Add New',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(width: 40),
                    ElevatedButton(
                      onPressed: () {
                        submit();
                      },
                      child: Text(
                        'Submit',
                        style: TextStyle(fontSize: 17),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Card(
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Selected Beverage:", style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(height: 5),
                        Text(selectedBeverage),
                        SizedBox(height: 10),
                        Text("Quantity:", style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(height: 5),
                        Text(selectedQuantity.toString()),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:date_time/date_time.dart';
import 'package:intl/intl.dart';
import 'package:flutter/foundation.dart';

final client = SupabaseClient('https://wbkncqghgyqvpxcbveus.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6India25jcWdoZ3lxdnB4Y2J2ZXVzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjE3NTk2NjIsImV4cCI6MjAzNzMzNTY2Mn0.HKgVYBkvm7Gdm7wQP6WYFevynMcAijL1Hnl4jDwaTQ4');

final supabase = Supabase.instance.client;


class ServiceDB extends ChangeNotifier {
  List<Map<dynamic, dynamic>> _dataList = [];

  List<Map<dynamic, dynamic>> get dataList => _dataList;

  String? beverageChosen = 'None';
  double? beverageAmount = 0;

  Future<List<Map<dynamic, dynamic>>> getData() async {
    final response = await supabase.from('beverage').select('*');

    _dataList = List<Map<dynamic, dynamic>>.from(response);
    beverageChosen = _dataList[0]['type'];
    beverageAmount = _dataList[0]['quantity'];
    notifyListeners();
    return _dataList;
  } 

  Future<void> updateDataValues(String type, double quantity) async {
    for (var item in _dataList) {
      if (item['type'] == type) {
        item['quantity'] = quantity;
        notifyListeners();
        break;
      }
    }
    await supabase
      .from('beverage')
      .update({'quantity': quantity}).eq('type', type);
    insertDateData(type, quantity);
  }

  Future<void> addBeverage(String type, double quantity) async {
    dataList.insert(dataList.length, {'type': type, 'quantity': quantity});
    await supabase.from('beverage').insert({'type': type, 'quantity': quantity});
    insertDateData(type, quantity);
    notifyListeners();
  }

  Future<void> insertDateData(String type, double quantity) async {
  String date = await getDate();
  print('Formatted date: $date');
  print(type);
  print(quantity);

  final response =
      await supabase.rpc('update_beverages', params: {
    'date': date,
    'new_beverage': {type: quantity}
  });

  if (response == null) {
    print('Error: Response is null');
    return;
  }

  if (response.error != null) {
    print('Error: ${response.error!.message}');
  } else {
    print('Data updated successfully');
  }
}
}

DateTime parseDate(String dateString) {
  var formatter = DateFormat('yyyy-MM-dd');
  return formatter.parse(dateString);
}

Future<String> getDate() async {
  DateTime now = DateTime.now();
  var formatter = DateFormat('yyyy-MM-dd');
  String formattedDate = formatter.format(now);
  return formattedDate;
}







/*
Future<List<Map<dynamic, dynamic>>> getData() async {
  final response = await supabase.from('beverage').select('type').select('*');
  if (response.isNotEmpty) {
    print(response);
    List<Map<String, dynamic>> data = List<Map<String, dynamic>>.from(response);
    return data;
  } else {
    throw "Error";
  }
}

*/


//final response = await supabase.from('beverage').select().eq('type', 'Coca Cola Zero');